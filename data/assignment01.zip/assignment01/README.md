

| Student    | CASP16 Target  | experimental structure | 
| ---------- | -------------- | ---------------------- | 
| Tanzeela Noreen Alvi | [T2280](https://predictioncenter.org/casp16/target.cgi?id=325&view=regular) |  PDB: [9f5m](https://www.rcsb.org/structure/9F5M) | 
| Ahmed Fadlelmawla    | [T1299](https://predictioncenter.org/casp16/target.cgi?id=359&view=regular) | PDB: [9fjl](https://www.rcsb.org/structure/9FJL) |
| Katherine Hurm       | [T1212](https://predictioncenter.org/casp16/target.cgi?id=75&view=regular)  | PDB: [9B0L](https://www.rcsb.org/structure/9B0L) | 
| Anthony Joson        | [T1214](https://predictioncenter.org/casp16/target.cgi?id=72&view=regular)  | PDB: [9C4O](https://www.rcsb.org/structure/9C4O) |
| Annie Kuo            | [T1266](https://predictioncenter.org/casp16/target.cgi?id=184&view=regular) | PDB: [8QFB](https://www.rcsb.org/structure/8QFB) |
| Chelsea R Lloyd        | [T2280](https://predictioncenter.org/casp16/target.cgi?id=325&view=regular) |  PDB: [9f5m](https://www.rcsb.org/structure/9F5M) |
| Hemanth Mandya Nagaiah | [T1299](https://predictioncenter.org/casp16/target.cgi?id=359&view=regular) | PDB: [9fjl](https://www.rcsb.org/structure/9FJL) | 
| Tiff Ongtowasruk       | [T1266](https://predictioncenter.org/casp16/target.cgi?id=184&view=regular) | PDB: [8QFB](https://www.rcsb.org/structure/8QFB) |
| Samar Oubarri          | [T1212](https://predictioncenter.org/casp16/target.cgi?id=75&view=regular)  | PDB: [9B0L](https://www.rcsb.org/structure/9B0L) |
| Hyosuk Seo             | [T1214](https://predictioncenter.org/casp16/target.cgi?id=72&view=regular)  | PDB: [9C4O](https://www.rcsb.org/structure/9C4O) |
